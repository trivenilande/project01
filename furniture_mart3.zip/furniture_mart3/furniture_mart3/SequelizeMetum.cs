﻿using System;
using System.Collections.Generic;

#nullable disable

namespace furniture_mart3
{
    public partial class SequelizeMetum
    {
        public string Name { get; set; }
    }
}
