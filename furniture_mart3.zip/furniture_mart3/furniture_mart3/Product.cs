﻿using System;
using System.Collections.Generic;

#nullable disable

namespace furniture_mart3
{
    public partial class Product
    {
        public Product()
        {
            Carts = new HashSet<Cart>();
        }

        public int Id { get; set; }
        public string ProductName { get; set; }
        public string Image { get; set; }
        public double? Price { get; set; }
        public string Category { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
        public bool? InCart { get; set; }
        public string Description { get; set; }

        public virtual ICollection<Cart> Carts { get; set; }
    }
}
